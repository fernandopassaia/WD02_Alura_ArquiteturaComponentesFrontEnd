const theme = {
  typography: {
    fontFamily: '"Open Sans", sans-serif',
  }
};

export default theme;
