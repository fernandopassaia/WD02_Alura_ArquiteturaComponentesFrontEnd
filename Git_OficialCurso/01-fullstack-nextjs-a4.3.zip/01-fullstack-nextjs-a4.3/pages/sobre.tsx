import Link from "@src/components/Link/Link";

export default function AboutScreen() {
  return (
    <div>
      Sobre!
      <Link href="/">
        Voltar para home
      </Link>
    </div>
  )
}
