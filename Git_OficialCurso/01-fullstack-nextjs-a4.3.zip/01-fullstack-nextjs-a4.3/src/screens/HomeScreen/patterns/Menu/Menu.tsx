import Box from "@src/components/Box/Box";
import Text from "@src/components/Text/Text";

export default function Menu() {
  return (
    <Box>
      <Text>
        Menu
      </Text>
    </Box>
  )
}
