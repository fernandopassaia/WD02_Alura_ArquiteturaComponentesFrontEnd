import Box from "@src/components/Box/Box";
import Text from "@src/components/Text/Text";

export default function Background() {
  return (
    <Box>
      <Text>
        Background
      </Text>
    </Box>
  )
}
